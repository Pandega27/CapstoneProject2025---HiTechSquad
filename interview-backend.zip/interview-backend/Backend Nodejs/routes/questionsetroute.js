// routes/questionSets.routes.js
import express from "express";
import { getDB } from '../db/mongo.js'// <-- matches the file you uploaded (mongo.js)

const router = express.Router();
const COLL = "Interview_Questions";

// GET /question-sets  → [{ title, description, questionsCount, estimatedTime }]
router.get("/", async (_req, res) => {
    try {
        const coll = getDB().collection(COLL);

        const pipeline = [
            {
                $group: {
                    _id: "$setName",
                    questionsCount: { $sum: 1 },
                    description: { $first: "$description" },     // optional fields in docs
                    estimatedTime: { $first: "$estimatedTime" }, // optional fields in docs
                },
            },
            {
                $project: {
                    _id: 0,
                    title: "$_id",
                    description: 1,
                    questionsCount: 1,
                    estimatedTime: 1,
                },
            },
            { $sort: { title: 1 } },
        ];

        const rows = await coll.aggregate(pipeline).toArray();

        res.json(
            rows.map((s) => ({
                title: s.title,
                description: s.description || "",
                questionsCount: s.questionsCount || 0,
                estimatedTime: s.estimatedTime ?? null,
            }))
        );
    } catch (err) {
        console.error("[GET /question-sets]", err);
        res.status(500).json({ error: "Failed to fetch question sets" });
    }
});

// GET /question-sets/:title → { title, description, questions, estimatedTime }
router.get("/:title", async (req, res) => {
    try {
        const title = decodeURIComponent(req.params.title);
        const coll = getDB().collection(COLL);

        const pipeline = [
            { $match: { setName: title } },
            // sort human-like for questionId "1.2", "2.10", etc.
            {
                $addFields: {
                    _qidParts: {
                        $map: {
                            input: {
                                $split: [
                                    {
                                        $cond: [
                                            { $isNumber: "$questionId" },
                                            { $toString: "$questionId" },
                                            { $ifNull: ["$questionId", ""] },
                                        ],
                                    },
                                    ".",
                                ],
                            },
                            as: "p",
                            in: {
                                $convert: {
                                    input: "$$p",
                                    to: "double",
                                    onError: 1e9,
                                    onNull: 1e9,
                                },
                            },
                        },
                    },
                },
            },
            { $sort: { "_qidParts.0": 1, "_qidParts.1": 1, "_qidParts.2": 1, questionId: 1 } },
            {
                $group: {
                    _id: "$setName",
                    questions: { $push: "$question" },
                    description: { $first: "$description" },
                    estimatedTime: { $first: "$estimatedTime" },
                },
            },
            { $project: { _id: 0, title: "$_id", questions: 1, description: 1, estimatedTime: 1 } },
        ];

        const doc = await coll.aggregate(pipeline).next();
        if (!doc) return res.status(404).json({ error: `No set named '${title}'` });

        res.json({
            title: doc.title,
            description: doc.description || "",
            questions: doc.questions || [],
            estimatedTime: doc.estimatedTime ?? null,
        });
    } catch (err) {
        console.error("[GET /question-sets/:title]", err);
        res.status(500).json({ error: "Failed to fetch question set detail" });
    }
});

export default router;
