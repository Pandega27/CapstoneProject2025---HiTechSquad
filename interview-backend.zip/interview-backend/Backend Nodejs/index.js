import express from 'express'
import cors from 'cors'
import dotenv from 'dotenv'
import multer from 'multer'
import AWS from 'aws-sdk'
import fs from 'fs'
import axios from 'axios'
import FormData from 'form-data'
import bcrypt from 'bcryptjs';
import { connectDB, getDB } from './db/mongo.js'
 
// ====== NEW: mount question sets routes (for Android) ======
import questionsetroute from './routes/questionsetroute.js'
 
dotenv.config()
const app = express()
const PORT = process.env.PORT || 3001
 
app.use(cors())
app.use(express.json())
 
const upload = multer({ dest: 'uploads/' })
 
// ====== AWS S3 ======
AWS.config.update({
  accessKeyId: process.env.AWS_ACCESS_KEY_ID,
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  region: process.env.AWS_REGION,
})
const s3 = new AWS.S3()

// ====== APIs keys ======
const ELEVENLABS_API_KEY = process.env.ELEVENLABS_API_KEY
const VLLM_URL =
  process.env.VLLM_URL ||
  'https://<your-pod-id>-8000.proxy.runpod.net/v1/chat/completions'

// ====== Helper: extract JSON safely ======
function extractJSON(text) {
  const match = text.match(/\{[\s\S]*\}/m)
  if (match) {
    try {
      return JSON.parse(match[0])
    } catch (e) {
      console.error('❌ Extracted JSON parse error:', e.message)
    }
  }
  return null
}
 
// ====== hàm gọi LLaMA ======
async function summarizeWithLLaMA(payload) {
  if (!payload.transcript && !payload.s3_url) {
    throw new Error('Need transcript or s3_url for summarization')
  }
 
  const transcript = payload.transcript || 'Transcript not available.'
 
  const body = {
    model: 'meta-llama/Meta-Llama-3-8B-Instruct',
    messages: [
      {
        role: 'system',
        content: `
Bạn là trợ lý tóm tắt cuộc phỏng vấn/cuộc họp bằng TIẾNG VIỆT. ĐẶC BIỆT CHỈ TRẢ LỜI BẰNG TIẾNG VIỆT KHÔNG BẰNG TIẾNG KHÁC
YÊU CẦU:
- summary: 5–10 câu súc tích dựa vào bài phỏng vấn, vẫn đầy đủ các ý chính và giữ nguyên bối cảnh nông nghiệp và trang trại và tóm tắt theo xưng hô theo ngôi thứ 3 .
- keyPoints: đưa ra 5–8 key points dựa vào bài phỏng vấn và phải giữ nguyên ngữ cảnh nông nghiệp và trang trại tất cả key points bắt đầu bằng - và vẫn phải đầy đủ các ý chính nhé.
- actionItems: 3–6 việc cần làm.
- suggestions: 5–8 gợi ý cải thiện cũng như cách phát triển, khắc phục thực tế những vấn đề được nhắc đến trong bài phỏng vấn được nhắc đến và đồng thời chèn thêm các link bài báo hay link youtube còn hoạt động và truy cập được để góp phần củng cố và tham khảo cho các gợi ý đó và vẫn phải giữ nguyên ngữ cảnh nông nghiệp và nông trại nhé .
- sentiment: "positive" | "neutral" | "negative".
Trả về đúng JSON.
        `,
      },
      {
        role: 'user',
        content: transcript,
      },
    ],
    max_tokens: 800,
  }
 
    try {
    const resp = await axios.post(VLLM_URL, body, {
      headers: { 'Content-Type': 'application/json' },
      timeout: 600000,
    })

    const text = resp.data.choices[0].message.content.trim()
    console.log('🔍 Raw LLaMA output:', text)
 
    const parsed = extractJSON(text)
 
    if (!parsed) {
      console.warn('⚠️ LLaMA returned non-JSON, fallback minimal.')
      return {
        summary: text,
        keyPoints: [],
        actionItems: [],
        suggestions: [],
        sentiment: 'neutral',
      }
    }
    return parsed
  } catch (err) {
    console.error('❌ LLaMA summarization error:', err.message)
    return {
      summary: 'LLaMA service unavailable, please retry later.',
      keyPoints: [],
      actionItems: [],
      suggestions: [],
      sentiment: 'neutral',
    }
  }
}
 
/**
 * API: Upload Audio -> S3 -> STT -> LLama -> MongoDB
 */
app.post('/upload-audio', upload.single('audio'), async (req, res) => {
  console.log('📥 Nhận yêu cầu upload...')
  console.log('form fields:', req.body)
  console.log('req.body.questionSetName:', req.body.questionSetName);

  const file = req.file
  let email = req.body.email
  const interviewee_name = (req.body.interviewee_name || '').trim() || null
  const questionSetName = req.body.questionSetName || req.body.question_set || null;
  
  if (!file || !email) {
    console.error('❌ Thiếu file hoặc email:', { file, email })
    return res.status(400).json({ success: false, message: 'Missing file or email' })
  }
 
  if (typeof email === "string") {
    email = email.replace(/^"+|"+$/g, "")
  }
 
  console.log('🎵 File:', file.originalname)
  console.log('📩 Email (sanitized):', email)
 
  const tempFilePath = file.path
 
  try {
    // 1) Upload to S3
    console.log('⬆️ Uploading to S3...')
    const fileStream = fs.createReadStream(tempFilePath)
    const key = `audio/${Date.now()}_${file.originalname}`
    const uploadParams = {
      Bucket: process.env.AWS_BUCKET_NAME,
      Key: key,
      Body: fileStream,
      ContentType: file.mimetype,
    }
    const s3Result = await s3.upload(uploadParams).promise()
    const s3Url = s3Result.Location
    console.log('✅ Uploaded to S3:', s3Url)
 
    // 2) STT ElevenLabs
    console.log('🧠 Requesting STT from ElevenLabs with S3 public URL...')
    const form = new FormData()
    form.append('cloud_storage_url', s3Url)
    form.append('model_id', 'scribe_v1')
    form.append('language', 'vi')
 
    const sttResponse = await axios.post(
      'https://api.elevenlabs.io/v1/speech-to-text',
      form,
      {
        headers: { ...form.getHeaders(), 'xi-api-key': ELEVENLABS_API_KEY },
        maxBodyLength: Infinity,
        maxContentLength: Infinity,
      }
    )
    const transcript = sttResponse.data?.text || 'No transcript available'
    console.log('📝 Transcript length:', transcript.length)
 
    // 3) Summarize with LLaMA
    console.log('✨ Requesting AI summary from LLaMA...')
    const ai = await summarizeWithLLaMA({ transcript })
    console.log('✅ LLaMA summarized successfully.')
 
    // 4) Save to MongoDB
    const db = getDB()
    const doc = {
      email,
      normalized_email: (email || '').trim().toLowerCase(),
      file_name: file.originalname,
      s3_url: s3Url,
      uploaded_at: new Date(),
      transcript,
      interviewee_name,
      question_set: questionSetName,
      summary: ai.summary,
      key_points: ai.keyPoints,
      action_items: ai.actionItems,
      suggestions: ai.suggestions,
      sentiment: ai.sentiment,
      summarized_at: new Date()
    }
 
    await db.collection('recordings').insertOne(doc)
    console.log('✅ Saved recording to MongoDB')
 
    res.json({
      success: true,
      url: s3Url,
      transcript,
      ai_summary: {
        summary: doc.summary,
        key_points: doc.key_points,
        action_items: doc.action_items,
        suggestions: doc.suggestions,
        sentiment: doc.sentiment
      }
    })
  } catch (err) {
    console.error('❌ Error during upload/STT/summarization:', err.message)
    res.status(500).json({
      success: false,
      message: 'An error occurred during processing.',
      error: err.message,
      details: err.response?.data || null
    })
  } finally {
    if (file && fs.existsSync(tempFilePath)) {
      fs.unlinkSync(tempFilePath)
      console.log('🧹 Đã xóa file tạm:', tempFilePath)
    }
  }
})
 
/**
 * API: Get all questions
 */
app.get('/api/questions', async (req, res) => {
  try {
    const db = getDB()
    const questions = await db.collection('questions').find().toArray()
    res.json(questions)
  } catch (err) {
    console.error('❌ Failed to fetch questions:', err)
    res.status(500).json({ message: 'Internal server error' })
  }
})
 
/**
 * API: Lấy danh sách bản ghi âm theo email
 */
app.get('/api/recordings', async (req, res) => {
  try {
    let { email, limit = '1000' } = req.query
    if (!email || typeof email !== 'string') {
      return res.status(400).json({ error: 'email is required' })
    }
 
    res.set('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate')
    res.set('Pragma', 'no-cache')
 
    const trimmed = email.trim()
    const escaped = trimmed.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
    const query = { email: { $regex: `^${escaped}$`, $options: 'i' } }
 
    const lim = Math.min(parseInt(limit, 10) || 1000, 10000)
    const db = getDB()
    const recordings = await db
      .collection('recordings')
      .find(query)
      .sort({ uploaded_at: -1 })
      .limit(lim)
      .toArray()
 
    res.json(recordings)
  } catch (err) {
    console.error('GET /api/recordings error:', err)
    res.status(500).json({ error: 'Internal server error' })
  }
})
 
// server.js (or wherever /api/login is)
app.post('/api/login', async (req, res) => {
  try {
    let { email, password } = req.body || {};
    if (!email || !password) {
      return res.status(400).json({ success: false, message: 'Email and password are required' });
    }

    // normalize + case-insensitive find
    email = String(email).trim();
    const escape = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const emailRegex = new RegExp(`^${escape(email)}$`, 'i');

    const db = getDB();
    const user = await db.collection('users').findOne({ email: emailRegex });
    if (!user) {
      return res.status(401).json({ success: false, message: 'Incorrect email or password. Please try again.' });
    }

    let ok = false;

    // Prefer hashed if present
    if (user.passwordHash && typeof user.passwordHash === 'string') {
      ok = await bcrypt.compare(password, user.passwordHash);
    } else if (typeof user.password === 'string') {
      ok = password === user.password; // legacy users
    }

    if (!ok) {
      return res.status(401).json({ success: false, message: 'Incorrect email or password. Please try again.' });
    }

    return res.json({ success: true, message: 'Login successful' });
  } catch (e) {
    console.error('LOGIN error:', e);
    return res.status(500).json({ success: false, message: 'Internal server error' });
  }
});

// server.js (add once)
app.get('/api/user', async (req, res) => {
  try {
    const { email } = req.query;
    if (!email) return res.status(400).json({ message: 'email is required' });

    const escape = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const emailRegex = new RegExp(`^${escape(email.trim())}$`, 'i');

    const db = getDB();
    const user = await db.collection('users').findOne(
      { email: emailRegex },
      { projection: { password: 0, passwordHash: 0 } }
    );
    if (!user) return res.status(404).json({ message: 'not found' });

    res.json({
      email: user.email,
      username: user.username || null
    });
  } catch (e) {
    res.status(500).json({ message: 'internal error' });
  }
});

 
// Submit Recording API
app.post('/api/submit-recording', async (req, res) => {
  try {
    const { email, file_name } = req.query; 
    if (!email || !file_name) {
      return res.status(400).json({ error: 'email and file_name are required' });
    }

    const db = getDB();

    // Find the source record
    const rec = await db.collection('recordings').findOne({ email, file_name });
    if (!rec) return res.status(404).json({ error: 'Recording not found' });

    // Prepare a copy (remove _id to avoid duplicate key)
    const copy = { ...rec, submitted_at: new Date() };
    delete copy._id;

    // Upsert into "submitted" collection keyed by email + file_name
    await db.collection('submitted').updateOne(
      { email, file_name },
      { $set: copy },
      { upsert: true }
    );

    res.json({ submitted: true });
  } catch (err) {
    console.error('POST /api/submit-recording error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});


/**
 * API: Xóa một bản ghi âm
 */
app.delete('/api/recordings', async (req, res) => {
  try {
    const { email, file_name } = req.query
    if (!email || !file_name) {
      return res.status(400).json({ error: 'email and file_name are required' })
    }
 
    const db = getDB()
    const rec = await db.collection('recordings').findOne({ email, file_name })
    if (!rec) return res.status(404).json({ error: 'Recording not found' })
 
    try {
      const key = decodeURIComponent(rec.s3_url.split('.amazonaws.com/')[1] || '')
      if (key) await s3.deleteObject({ Bucket: process.env.AWS_BUCKET_NAME, Key: key }).promise()
    } catch (e) {
      console.warn('S3 delete error (ignored):', e.message)
    }
 
    await db.collection('recordings').deleteOne({ _id: rec._id })
    res.json({ deleted: true })
  } catch (err) {
    console.error('DELETE /api/recordings error:', err)
    res.status(500).json({ error: 'Internal server error' })
  }
})
 
/**
 * API: Đăng xuất (giả lập)
 */
app.post('/api/signout', (req, res) => {
  res.json({ success: true, message: 'User signed out successfully' })
})
 
/**
 * API: Tóm tắt on demand
 */
app.post('/ai/summarize', async (req, res) => {
  try {
    const { email, file_name, transcript, s3_url, mimeType = 'audio/m4a' } = req.body
    let payload = { transcript, s3_url, mimeType }
 
    if (!transcript && !s3_url && email && file_name) {
      const db = getDB()
      const rec = await db.collection('recordings').findOne({ email, file_name })
      if (!rec) return res.status(404).json({ error: 'Recording not found' })
      payload = { transcript: rec.transcript, s3_url: rec.s3_url, mimeType }
    }
 
    console.log('✨ Requesting on-demand summarization (LLaMA)...')
    const ai = await summarizeWithLLaMA(payload)
    console.log('✅ On-demand summarization done.')
 
    if (email && file_name) {
      const db = getDB()
      await db.collection('recordings').updateOne(
        { email, file_name },
        {
          $set: {
            summary: ai.summary,
            key_points: ai.keyPoints || [],
            action_items: ai.actionItems || [],
            suggestions: ai.suggestions || [],
            sentiment: ai.sentiment,
            summarized_at: new Date(),
          },
        },
        { upsert: true }
      )
    }
    res.json(ai)
  } catch (err) {
    console.error('❌ summarize error:', err)
    res.status(500).json({ error: err.message })
  }
})
 
app.use('/question-sets', questionsetroute)
 
async function startServer() {
  await connectDB()
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`✅ Connected to MongoDB`)
    console.log(`🚀 Server running on http://0.0.0.0:${PORT}`)
  })
}
startServer()
 
 